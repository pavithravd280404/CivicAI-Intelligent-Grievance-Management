"""Real SMTP email verification + complaint receipt with original attachment.
No email is claimed sent unless SMTP send_message returns successfully.
"""
from __future__ import annotations
from email.message import EmailMessage
from email.utils import parseaddr
import os
import re
import smtplib
import ssl

MAX_FILE_BYTES = 4 * 1024 * 1024
ALLOWED_MIME = {
    'application/pdf': ('application', 'pdf'),
    'text/plain': ('text', 'plain'),
    'image/png': ('image', 'png'),
    'image/jpeg': ('image', 'jpeg'),
}


def email_valid(address: str) -> bool:
    name, parsed = parseaddr(address.strip())
    return not name and parsed == address.strip() and bool(re.fullmatch(
        r'[A-Za-z0-9][A-Za-z0-9._%+\-]{0,63}@[A-Za-z0-9.\-]+\.[A-Za-z]{2,24}', parsed
    )) and len(parsed) <= 254


def configured() -> bool:
    return all(os.getenv(k, '').strip() for k in ('SMTP_USER', 'SMTP_PASSWORD', 'SMTP_FROM'))


def _send(recipient: str, subject: str, body: str,
          filename: str | None = None, attachment: bytes | None = None,
          mime: str | None = None) -> None:
    if not email_valid(recipient):
        raise ValueError('Recipient email address invalid')
    if not configured():
        raise RuntimeError('SMTP is not configured. See .env.example')
    msg = EmailMessage()
    msg['From'] = os.environ['SMTP_FROM']
    msg['To'] = recipient
    msg['Subject'] = subject
    msg.set_content(body)
    if filename is not None and attachment is not None:
        if len(attachment) > MAX_FILE_BYTES:
            raise ValueError('Attachment is larger than 4 MB')
        if mime not in ALLOWED_MIME:
            raise ValueError('Unsupported file type')
        maintype, subtype = ALLOWED_MIME[mime]
        safe_name = re.sub(r'[^a-zA-Z0-9_.-]', '_', filename.split('/')[-1].split('\\')[-1])[:100]
        msg.add_attachment(attachment, maintype=maintype, subtype=subtype,
                           filename=safe_name or 'complaint_attachment')
    host = os.getenv('SMTP_HOST', 'smtp.gmail.com')
    port = int(os.getenv('SMTP_PORT', '465'))
    with smtplib.SMTP_SSL(host, port, timeout=20, context=ssl.create_default_context()) as smtp:
        smtp.login(os.environ['SMTP_USER'], os.environ['SMTP_PASSWORD'].replace(' ', ''))
        smtp.send_message(msg)


def send_verification_code(recipient: str, code: str) -> None:
    _send(recipient, 'CivicAI email verification code',
          f'Your CivicAI verification code is {code}. It expires in 10 minutes.\n'
          'If you did not request this, ignore this message.\n'
          'CivicAI is an educational prototype, not a government service.')


def send_receipt(recipient: str, ticket: str, category: str, priority: str,
                 description: str, filename: str | None,
                 file_bytes: bytes | None, mime: str | None) -> None:
    body = (
        'Your CivicAI complaint was saved successfully.\n\n'
        f'Ticket ID: {ticket}\nCategory suggestion: {category}\n'
        f'Priority suggestion: {priority}\n\n'
        f'Your description:\n{description[:3000]}\n\n'
        'Your original uploaded file is attached if you provided one.\n'
        'You can track your ticket in CivicAI with this ID and your email address.\n'
        'This is an academic demo; no municipal authority has received your complaint.\n'
    )
    _send(recipient, f'CivicAI complaint receipt: {ticket}', body, filename, file_bytes, mime)
