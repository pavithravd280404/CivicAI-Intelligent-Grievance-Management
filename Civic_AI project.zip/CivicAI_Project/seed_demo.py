"""Add clearly labeled SAMPLE records for a classroom admin dashboard demo.

Usage: python seed_demo.py
Run only on an empty CivicAI database. No email or Gemini requests are made.
"""
from __future__ import annotations

from database import init_db, list_complaints, save_complaint, update_email_status, update_status
from genai_service import DEPARTMENTS

DEMO = [
    ('Roads & Potholes', 'High', 'Pothole near the college entrance causing two-wheeler falls.', 'MG Road, Ward 2', 'In Progress'),
    ('Water Supply', 'Medium', 'Water pipeline has been leaking near the bus stop for two days.', 'Ward 4', 'Pending'),
    ('Garbage & Waste', 'Medium', 'Community garbage bins have not been emptied this week.', 'Ward 6', 'Done'),
    ('Street Lighting', 'High', 'Street lights are not working along the school road.', 'Ward 1', 'Pending'),
    ('Drainage & Sewage', 'High', 'Open drain is overflowing near residential houses.', 'Ward 3', 'In Progress'),
    ('Public Safety', 'High', 'Open electrical wire is hanging over the footpath.', 'Ward 5', 'Pending'),
    ('Parks & Trees', 'Low', 'Overgrown shrubs need trimming in the public park.', 'Ward 8', 'Done'),
    ('Roads & Potholes', 'Medium', 'Road surface has developed multiple cracks near the market.', 'Ward 2', 'Pending'),
    ('Garbage & Waste', 'Medium', 'Plastic waste is scattered beside the lake walkway.', 'Ward 7', 'In Progress'),
    ('Water Supply', 'Medium', 'Tap water supply is interrupted every morning.', 'Ward 4', 'Done'),
    ('Street Lighting', 'Low', 'A park pathway lamp is flickering at night.', 'Ward 8', 'Done'),
    ('Drainage & Sewage', 'High', 'Drain blockage is flooding the service road after rainfall.', 'Ward 9', 'Pending'),
]


def main() -> None:
    init_db()
    if list_complaints():
        print('Demo seeding skipped: database already contains complaints.')
        return
    for i, (category, priority, description, location, status) in enumerate(DEMO, start=1):
        info = {
            'name': f'Demo Citizen {i}',
            'email': f'citizen{i}@example.com',
            'location': location,
            'description': description,
            'attachment_name': 'sample_complaint.txt',
            'category_ml': category,
            'category_llm': None,
            'priority': priority,
            'department': DEPARTMENTS[category],
            'summary': description,
            'citizen_reply': 'Demo record only; no email was sent.',
            'llm_status': 'Seeded demo — Gemini not called',
        }
        ticket = save_complaint(info)
        update_status(ticket, status)
        update_email_status(ticket, 'Not sent (seeded demo)')
    print(f'Success: inserted {len(DEMO)} synthetic demo complaints into SQLite.')
    print('These rows are fabricated examples; no real emails or Gemini calls occurred.')


if __name__ == '__main__':
    main()
