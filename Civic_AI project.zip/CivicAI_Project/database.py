"""SQLite persistence for the educational complaint portal."""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import sqlite3
import uuid

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / 'data' / 'civicai.sqlite3'
STATUSES = ('Pending', 'In Progress', 'Done')


def connect(db_path: Path | None = None):
    path = db_path or DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path: Path | None = None):
    with connect(db_path) as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS complaints (
          ticket TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          email TEXT NOT NULL,
          location TEXT NOT NULL,
          description TEXT NOT NULL,
          attachment_name TEXT,
          category_ml TEXT NOT NULL,
          category_llm TEXT,
          priority TEXT NOT NULL,
          department TEXT NOT NULL,
          summary TEXT NOT NULL,
          citizen_reply TEXT NOT NULL,
          llm_status TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'Pending',
          email_status TEXT NOT NULL DEFAULT 'Pending',
          created_at TEXT NOT NULL
        )''')
        # Store evidence separately so admin complaint listings don't load large files.
        conn.execute('''CREATE TABLE IF NOT EXISTS complaint_attachments (
          ticket TEXT PRIMARY KEY REFERENCES complaints(ticket),
          filename TEXT NOT NULL,
          mime TEXT NOT NULL,
          contents BLOB NOT NULL
        )''')
        # Migration for projects created before the three-state admin workflow.
        conn.execute("UPDATE complaints SET status='Pending' WHERE status IN ('Submitted', 'Under Review', 'Rejected')")
        conn.execute("UPDATE complaints SET status='Done' WHERE status='Resolved'")


def save_complaint(info: dict, db_path: Path | None = None, *,
                   attachment_bytes: bytes | None = None,
                   attachment_mime: str | None = None) -> str:
    init_db(db_path)
    ticket = 'CIV-' + uuid.uuid4().hex[:10].upper()
    with connect(db_path) as conn:
        conn.execute('''INSERT INTO complaints
            (ticket,name,email,location,description,attachment_name,
            category_ml,category_llm,priority,department,summary,citizen_reply,llm_status,created_at)
            VALUES (:ticket,:name,:email,:location,:description,:attachment_name,
            :category_ml,:category_llm,:priority,:department,:summary,:citizen_reply,:llm_status,:created_at)''',
            {**info, 'ticket':ticket, 'created_at':datetime.now(timezone.utc).isoformat(timespec='seconds')})
        if attachment_bytes is not None:
            if not attachment_mime or not info.get('attachment_name'):
                raise ValueError('Attachment MIME and name are required')
            if len(attachment_bytes) > 4 * 1024 * 1024:
                raise ValueError('Attachment exceeds 4 MB')
            conn.execute('''INSERT INTO complaint_attachments (ticket,filename,mime,contents)
                            VALUES (?,?,?,?)''',
                         (ticket, info['attachment_name'], attachment_mime, attachment_bytes))
    return ticket


def get_ticket(ticket: str, email: str, db_path: Path | None = None):
    init_db(db_path)
    with connect(db_path) as conn:
        row = conn.execute('SELECT * FROM complaints WHERE ticket=? AND LOWER(email)=LOWER(?)',
                           (ticket.strip().upper(), email.strip())).fetchone()
        return dict(row) if row else None


def list_complaints(db_path: Path | None = None) -> list[dict]:
    init_db(db_path)
    with connect(db_path) as conn:
        return [dict(r) for r in conn.execute('SELECT * FROM complaints ORDER BY created_at DESC')]


def update_status(ticket: str, status: str, db_path: Path | None = None):
    if status not in STATUSES:
        raise ValueError('Invalid status')
    with connect(db_path) as conn:
        conn.execute('UPDATE complaints SET status=? WHERE ticket=?', (status, ticket))


def update_email_status(ticket: str, status: str, db_path: Path | None = None):
    with connect(db_path) as conn:
        conn.execute('UPDATE complaints SET email_status=? WHERE ticket=?', (status, ticket))


def get_attachment(ticket: str, db_path: Path | None = None) -> dict | None:
    """Retrieve original uploaded evidence; only call from an authenticated admin page."""
    init_db(db_path)
    with connect(db_path) as conn:
        row = conn.execute('SELECT filename,mime,contents FROM complaint_attachments WHERE ticket=?',
                           (ticket.strip().upper(),)).fetchone()
        return dict(row) if row else None
