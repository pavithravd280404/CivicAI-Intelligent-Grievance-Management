from __future__ import annotations
from pathlib import Path
from email_service import email_valid, MAX_FILE_BYTES
from database import init_db, save_complaint, get_ticket, update_status, update_email_status, list_complaints, get_attachment
from genai_service import _parse_json, CATEGORIES, DEPARTMENTS
from data.generate_dataset import generate
from train_model import train_and_evaluate
from challenge_evaluate import run
import pandas as pd
import pytest


def test_synthetic_splits_no_leak(tmp_path):
    f = generate(tmp_path/'dataset.csv')
    df = pd.read_csv(f)
    training = df[df.split == 'train']
    testing = df[df.split == 'test']
    assert set(training.template_group).isdisjoint(testing.template_group)
    assert set(training.description).isdisjoint(testing.description)
    assert len(df) > 1000


def test_classifier_synthetic_94_target():
    _, metrics, _ = train_and_evaluate(save=False)
    assert metrics['category_accuracy'] >= 0.94
    assert metrics['train_rows'] == 1176
    assert metrics['test_rows'] == 392


def test_challenge_94_target():
    _, metrics = run()
    assert metrics['accuracy'] >= 0.94
    assert metrics['test_rows'] == 42


def test_email_validation():
    assert email_valid('student@example.com')
    assert email_valid('student+test@gmail.com')
    for e in ['oops', 'bad@@example.com', 'A <a@example.com>', 'x@example.com\nBCC: bad@evil.com']:
        assert not email_valid(e)


def test_db_persist_and_track(tmp_path):
    db = tmp_path/'civic.sqlite3'
    init_db(db)
    values = {
        'name':'Demo Student','email':'STUDENT@example.com','location':'Ward 12',
        'description':'Broken lamp', 'attachment_name':'report.txt',
        'category_ml':'Street Lighting','category_llm':None,
        'priority':'Medium','department':'Electrical & Street Lighting',
        'summary':'Lamp not working', 'citizen_reply':'Recorded', 'llm_status':'Missing Gemini'
    }
    ticket = save_complaint(values,db,attachment_bytes=b'My sample note', attachment_mime='text/plain')
    assert get_ticket(ticket,'student@example.com',db)['status'] == 'Pending'
    assert get_attachment(ticket,db)['contents'] == b'My sample note'
    assert get_ticket(ticket,'someoneelse@example.com',db) is None
    update_status(ticket,'In Progress',db)
    update_email_status(ticket,'Sent via SMTP',db)
    assert get_ticket(ticket,'student@example.com',db)['email_status'] == 'Sent via SMTP'
    assert list_complaints(db)[0]['status'] == 'In Progress'
    with pytest.raises(ValueError):
        update_status(ticket, 'SHUTDOWN',db)


def test_llm_parser():
    assert _parse_json('```json\n{"category":"Water Supply"}\n```')['category']=='Water Supply'
    assert len(CATEGORIES) == len(DEPARTMENTS)
    with pytest.raises(ValueError):
        _parse_json('[1,2]')


def test_admin_three_states_and_migration(tmp_path):
    from database import connect, STATUSES
    db = tmp_path / 'legacy.sqlite3'
    init_db(db)
    values = {'name':'Test', 'email':'student@example.com','location':'City',
        'description':'Demo issue', 'attachment_name':None,'category_ml':'Water Supply',
        'category_llm':None,'priority':'Low','department':'Water',
        'summary':'Demo','citizen_reply':'Receipt','llm_status':'offline'}
    ticket = save_complaint(values, db)
    assert tuple(STATUSES) == ('Pending', 'In Progress', 'Done')
    for status in STATUSES:
        update_status(ticket, status, db)
        assert get_ticket(ticket, 'student@example.com', db)['status'] == status
    with connect(db) as conn:
        conn.execute("UPDATE complaints SET status='Resolved' WHERE ticket=?",(ticket,))
    init_db(db)
    assert get_ticket(ticket, 'student@example.com', db)['status'] == 'Done'
