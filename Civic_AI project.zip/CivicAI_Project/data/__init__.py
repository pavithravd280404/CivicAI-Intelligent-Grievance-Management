"""Synthetic civic complaint benchmark generator."""
