"""Pure helpers for the authenticated administrator complaint list."""
from __future__ import annotations


def filter_admin_complaints(rows: list[dict], status: str = 'All', query: str = '') -> list[dict]:
    """Return matching case records; must only be used in authenticated admin UI."""
    needle = (query or '').strip().casefold()
    searchable = ('ticket', 'name', 'email', 'category_ml', 'location', 'description')
    result = []
    for row in rows:
        if status != 'All' and row.get('status') != status:
            continue
        if needle and not any(needle in str(row.get(field, '') or '').casefold() for field in searchable):
            continue
        result.append(row)
    return result
