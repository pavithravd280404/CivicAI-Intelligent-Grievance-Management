# NEW: Interactive administrator dashboard (CivicAI)

After signing in, click one of **Total Complaints**, **Done**, **In Progress** or **Pending** to filter the administrator complaint list. Click a **row** in the interactive table, or select a ticket ID, to open the full record: name, email, locality, original complaint text, ML and LLM categories, AI summary, priority, suggested department, email delivery and LLM status, creation date, and uploaded document download (for new submissions).

Use the three buttons in **Change complaint status**: **Pending**, **In Progress**, **Done**. Click **Save status**; SQLite persists the change and the citizen Track Complaint page will show it. Old rows are automatically migrated: `Submitted` / `Under Review` / `Rejected` → `Pending`, `Resolved` → `Done`. This is a local classroom prototype; no municipal system is contacted and no status-change email is sent.

**Files uploaded with earlier versions were not saved in the database**, so only their filenames can be displayed. New uploaded documents are retained locally as BLOBs in SQLite for authenticated administrator download. The original receipt email remains independent of this. Use only fictional or consented files, restrict `.env` and database access, and avoid deploying this prototype publicly.

**Quick update (PowerShell):**

```powershell
# Stop the old Streamlit server with Ctrl+C, then:
cd "$HOME\CivicAI_VisualMatch"
Expand-Archive -Path "$HOME\Downloads\CivicAI_ADMIN_UPDATE.zip" -DestinationPath "$HOME\CivicAI_VisualMatch" -Force
.\.venv\Scripts\python.exe -m streamlit run app.py
```

The update ZIP replaces only source code, tests and CSS; it does **not** replace your `.env`, `.venv`, or `data/civicai.sqlite3`. To log in, set your secret `ADMIN_PASSWORD` in `.env` and restart Streamlit. If you only see the old dashboard, check which folder your terminal is running from and refresh the page.

---

# NEW: Interactive administrator dashboard (CivicAI)

After signing in, click one of **Total Complaints**, **Done**, **In Progress** or **Pending** to filter the administrator complaint list. Click a **row** in the interactive table, or select a ticket ID, to open the full record: name, email, locality, original complaint text, ML and LLM categories, AI summary, priority, suggested department, email delivery and LLM status, creation date, and uploaded document download (for new submissions).

Use the three buttons in **Change complaint status**: **Pending**, **In Progress**, **Done**. Click **Save status**; SQLite persists the change and the citizen Track Complaint page will show it. Old rows are automatically migrated: `Submitted` / `Under Review` / `Rejected` → `Pending`, `Resolved` → `Done`. This is a local classroom prototype; no municipal system is contacted and no status-change email is sent.

**Files uploaded with earlier versions were not saved in the database**, so only their filenames can be displayed. New uploaded documents are retained locally as BLOBs in SQLite for authenticated administrator download. The original receipt email remains independent of this. Use only fictional or consented files, restrict `.env` and database access, and avoid deploying this prototype publicly.

**Quick update (PowerShell):**

```powershell
# Stop the old Streamlit server with Ctrl+C, then:
cd "$HOME\CivicAI_VisualMatch"
Expand-Archive -Path "$HOME\Downloads\CivicAI_ADMIN_UPDATE.zip" -DestinationPath "$HOME\CivicAI_VisualMatch" -Force
.\.venv\Scripts\python.exe -m streamlit run app.py
```

The update ZIP replaces only source code, tests and CSS; it does **not** replace your `.env`, `.venv`, or `data/civicai.sqlite3`. To log in, set your secret `ADMIN_PASSWORD` in `.env` and restart Streamlit. If you only see the old dashboard, check which folder your terminal is running from and refresh the page.

---

# IMPORTANT: run `START_HERE_FIRST.txt` for the UPDATED visual dashboard.

# CivicAI — GenAI + LLM + Complaint Email System

A **complete classroom project** with a Streamlit website, a Python Jupyter notebook, a trained scikit-learn category classifier, optional **Google Gemini LLM** analysis of complaint text/PDF/images, an SQLite complaint tracker, email verification, and **automatic complaint receipt emails containing the uploaded complaint file**.

> **Not an official municipal platform.** No complaint is forwarded to government offices. Use synthetic complaints during demonstration. This prototype is not ready for public internet deployment.

## 1. Project structure

```text
CivicAI_VisualMatch/
  app.py                         Streamlit website
  genai_service.py                Google Gemini LLM / multimodal file analysis
  ml_model.py                     Local classifier inference
  train_model.py                  Reproducible model training + test accuracy
  challenge_evaluate.py           Independent handcrafted challenge test
  email_service.py                SMTP email OTP + receipt with file attachment
  database.py                     SQLite complaint records and status
  notebooks/CivicAI_Model_Accuracy.ipynb
  data/generate_dataset.py        Explicitly synthetic sample dataset generator
  data/synthetic_civic_complaints.csv
  data/challenge_complaints.csv
  models/category_classifier.joblib
  reports/ml_metrics.json
  reports/challenge_metrics.json
  .env.example                    Sample config: copy to .env
  .streamlit/config.toml
  samples/sample_complaint.txt
  requirements.txt
  tests/
  seed_demo.py                   Optional synthetic dashboard data for presentations
```

## 2. Setup in VS Code (Windows PowerShell)

Extract this ZIP to a **fresh folder**, such as `C:\Users\pavit\CivicAI_GenAI_DemoReady`. Do not merge it with the earlier CivicAI version unless you know which files you are replacing.

```powershell
cd "$HOME\CivicAI_GenAI_DemoReady"
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

If `python` is not found, use the fully qualified path to your installed Python. `py` may be unavailable on your computer.

## 3. Reproduce the ML accuracy (no Gemini account required)

```powershell
.\.venv\Scripts\python.exe train_model.py
.\.venv\Scripts\python.exe challenge_evaluate.py
.\.venv\Scripts\python.exe -m pytest -q
```

The project includes a pre-trained artifact, but you should **retrain locally** so your evaluation is reproducible.

You can also open `notebooks/CivicAI_Model_Accuracy.ipynb` in VS Code with the Jupyter extension. Select the `.venv` Python kernel and click **Run All**.

### Accuracy claims — essential for your review

| Test | Samples | Measured accuracy | Meaning |
|------|---------|-------------------|---------|
| Held-out **synthetic templates** | 392 | **100.00%** | Test templates disjoint from training templates, but all data generated from curated patterns |
| Additional **handcrafted challenge** set | 42 | **97.62% (41/42)** | Small manual test; still not a real external field benchmark |
| Real municipal citizen complaints | 0 | **Unknown** | Must collect real, diverse, consented and labeled complaints to claim real deployment accuracy |
| Gemini LLM complaints | 0 | **Not measured** | Optional notebook cell evaluates LLM separately when a valid API key is configured |

**Do NOT say CivicAI is 100% accurate on actual complaints, or that the Gemini LLM scored 97.62%.** The percentages are for the **scikit-learn ML classifier**, not the LLM. Accuracy can be much lower on different wording, unseen languages, multiple simultaneous issues, or photographs with no description.

## 4. Setup Gemini GenAI

Create a key at https://aistudio.google.com/apikey . Copy `.env.example` to `.env`:

```powershell
Copy-Item .env.example .env
```

Edit `.env` using VS Code:

```dotenv
GEMINI_API_KEY=YOUR_REAL_GEMINI_API_KEY
GEMINI_MODEL=gemini-2.5-flash
```

When enabled, the Gemini LLM reads the description and the uploaded PDF, TXT, JPG or PNG file, and generates **a suggested category, priority, a summary and an acknowledgement**. The application clearly displays **ML category** and **Gemini category** separately. Gemini's results are never presented as measured ML accuracy. If Gemini fails, the complaint is still saved using ML only, with an explicit error.

## 5. Enable REAL automatic email receipts

The application requests the citizen's email **before** it makes the upload form visible. With SMTP configured, it emails a six-digit verification code. The user enters the code, then uploads a complaint file and submits. On success the app sends an **actual email receipt to that email address, with the original complaint file attached**.

For a personal Gmail account you generally need to enable **2-Step Verification** and create a separate **App Password** (NOT your usual Gmail login password): https://support.google.com/mail/answer/185833 . Set values in `.env`:

```dotenv
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_USER=your_actual_sender@gmail.com
SMTP_PASSWORD=YOUR_16_CHARACTER_APP_PASSWORD
SMTP_FROM=your_actual_sender@gmail.com
ADMIN_PASSWORD=CHOOSE_A_LONG_PRIVATE_ADMIN_PASSWORD
```

Use your actual account details; no credentials are included in this project. Gmail's SMTP uses encrypted port **465**. App passwords may be unavailable on some managed accounts. A transactional email provider with verified domain is preferable for production; this example is for a classroom/local demonstration.

Without SMTP config, the app runs in a clearly labeled **LOCAL DEMO mode** and **DOES NOT send emails**. This allows you to try the UI before configuring Gmail.

## 6. Launch the Streamlit website

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Browse to **http://localhost:8501**. Pages: Dashboard, Submit Complaint, Track Complaint, Admin Dashboard, About Project.

**Dashboard design:** The **Resolution Status chart and the Model Accuracy dashboard tab have been removed**. The administrator sees four summary cards (Total, Resolved, In Progress, Pending Review), a category donut chart, a recent-complaints table and a status-update form. Tracking and admin status updates still work.

**Optional demo data:** If you want a populated dashboard for a presentation, and your database is empty, run:

```powershell
.\.venv\Scripts\python.exe seed_demo.py
```

These are **fictional sample records**; they do not send email or call Gemini. The script does nothing if your database already contains complaints. This prevents accidental duplicate demo records.

**Accuracy metrics are still available in the Jupyter notebook and reports for your viva, but not shown inside the Streamlit dashboard.**

### Suggested demonstration

1. Configure Gemini, SMTP and admin password in `.env`.
2. Open **Submit Complaint** and enter an email address.
3. Receive the six-digit code and verify that email.
4. Enter a civic complaint and upload `samples/sample_complaint.txt`.
5. Submit and observe the trained classifier category, Gemini-generated summary/priority and ticket ID.
6. Open the inbox: the **automatic email receipt includes your original uploaded text file**.
7. Look up the ticket using the email and ticket ID.
8. Sign into Admin Dashboard to view analytics and update the ticket status.
9. Open the Jupyter accuracy notebook separately for your academic evaluation; the dashboard does not display accuracy.

## 7. Limitations and safety

- **Education only**: no genuine city-government integration or real ticket escalation.
- **No public deployment**: a public service would require abuse/rate limiting across IPs, CSRF/session protections, antivirus scans, MIME file validation beyond signatures, stronger auth, privacy policy and data retention/deletion controls.
- The recipient must verify their email by OTP when SMTP is configured. Local demo mode is intentionally **not verified** and cannot send mail.
- Complaint email addresses and descriptions are stored in local SQLite. Attachments are held in memory for sending but are not stored on disk.
- Google may receive uploaded complaint contents when Gemini is configured, so get consent and avoid private records in demos.
- Gemini's summaries/priority are suggestions; they can be wrong. Admin human review is required.
- ML accuracy on curated datasets **is not a prediction of real-world performance**.

## 8. Common troubleshooting

- `requirements.txt not found` → check `Get-ChildItem -Name` in the project folder.
- `ModuleNotFoundError` → install the dependencies using the same `.venv\Scripts\python.exe` executable.
- `Gemini key missing` → edit `.env`, save, then restart Streamlit.
- `SMTPAuthenticationError` → use a Gmail *App Password*, not your login password.
- `Email receipt NOT sent` → check SMTP configuration; the ticket can still be saved.
- `ML model missing` → run `python train_model.py` from the project root.

## Tools and methods

Scikit-learn: feature union with word and character TF-IDF, LinearSVC, precision, recall, F1, confusion matrix, disjoint template train/test split. Gemini uses the official `google-genai` Python SDK and structured JSON prompts. SMTP uses Python's `smtplib` and `EmailMessage` with attachments. SQLite uses `sqlite3`. Streamlit provides the website.


## 9. Night-before-review checklist

1. Verify `python -m pytest -q` shows the local tests pass.
2. Start Streamlit and check **Admin Dashboard** opens after setting `ADMIN_PASSWORD` in `.env`.
3. Check the **category donut chart** and complaints table; there should be **no Resolution Status chart**.
4. Verify there is **no Model Accuracy item in website navigation**; use the notebook for results.
5. If using SMTP, submit one test complaint with an email address you own; receive OTP, submit the file, and confirm the email **with attachment** arrived. A saved ticket alone does not guarantee email delivery.
6. If using Gemini, verify the sidebar says Gemini enabled, and submit a test complaint to check a real generated response. Never claim Gemini is enabled when the key is absent.
7. Keep the sample document and admin password ready. Stop the Streamlit server with Ctrl+C when finished.


## Admin click fix (22 Nov 2026)

After logging in, open **Admin Dashboard** (not the public Dashboard).
Click **Total / Pending / In Progress / Done** to filter, then click **Open details** on any complaint card.
The details panel appears directly beneath the filters and contains the citizen email,
full complaint, uploaded evidence, AI output, and **Pending / In Progress / Done** status controls.
All admin buttons are native Streamlit controls; the homepage overview remains non-interactive
for guests. If no complaints exist, submit a new one or run `seed_demo.py` for fictional demo examples.

For existing projects, replace `app.py`, add `admin_logic.py`, and retain your current `.env`,
`data/civicai.sqlite3`, and `.venv`. Stop and restart Streamlit after updating.
