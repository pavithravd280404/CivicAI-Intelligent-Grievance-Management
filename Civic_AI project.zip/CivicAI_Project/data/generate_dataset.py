"""Generate a reproducible, explicitly SYNTHETIC civic complaints benchmark.

Test examples use entirely held-out message templates, not rows randomly split
from the same template. Never describe results as real-world accuracy.
"""
from __future__ import annotations
from pathlib import Path
import csv
import random

ROOT = Path(__file__).resolve().parents[1]
CATEGORIES = {
    "Roads & Potholes": [
        "A pothole has appeared in the main road", "The road surface is broken and needs resurfacing",
        "Vehicles are struggling over deep potholes", "Asphalt has cracked along the road",
        "The pedestrian footpath has broken tiles", "Road repair work was left unfinished",
        "A damaged speed breaker is causing trouble", "There are dangerous cracks on the street surface",
        "The roadside pavement is badly damaged", "A collapsed section of road needs fixing",
        "There is a large crater in the carriageway", "Road maintenance is required near the junction",
        "Please fill the potholes on this road", "The uneven asphalt makes driving difficult",
        "The footpath is crumbling in several places", "A broken road patch is slowing down traffic",
    ],
    "Water Supply": [
        "The drinking water supply has stopped", "No water is coming from the household taps",
        "A municipal water pipeline is leaking", "The water pressure is extremely low",
        "The drinking water is muddy", "The neighborhood has irregular tap water supply",
        "A burst pipe is wasting fresh water", "The public water tap is not working",
        "Water tanker deliveries have not arrived", "The water supply valve is damaged",
        "We need repair of the leaking water line", "Tap water is unavailable each morning",
        "A broken water main needs urgent repair", "Water is seeping from a supply pipe",
        "The overhead public water tank is empty", "The community has not received drinking water",
    ],
    "Garbage & Waste": [
        "Garbage has not been collected for days", "The waste collection truck skipped our lane",
        "An overflowing trash bin is attracting pests", "Someone dumped rubbish beside the road",
        "Plastic waste is piling up outside homes", "The public dustbins are overflowing",
        "The sanitation team has not cleared household waste", "A garbage dump is producing a bad smell",
        "Recycling bins have not been emptied", "Rotting litter is scattered on the roadside",
        "The community waste pickup is overdue", "Please remove an illegal rubbish pile",
        "Dry garbage bags are scattered near the market", "The municipal trash containers need emptying",
        "Uncollected food waste attracts stray animals", "The garbage disposal point is overflowing",
    ],
    "Street Lighting": [
        "The streetlight has stopped working", "A lamp post is dark every night",
        "The road lighting fixture keeps flickering", "The street lamps are not turning on",
        "A broken light pole needs replacement", "The public lighting near the bus stand is faulty",
        "Several streetlights are out after sunset", "The LED lamp above the street is damaged",
        "Street illumination is missing on this lane", "The electric street lamp has a broken bulb",
        "Public street lighting is very dim", "The light fixture on the pole is not functioning",
        "Please repair the failed streetlight", "The lamps along this pathway remain off",
        "A street lamp keeps switching off at night", "The streetlight pole is leaning dangerously",
    ],
    "Drainage & Sewage": [
        "The sewage drain is blocked", "Wastewater is overflowing from the manhole",
        "The open drainage channel is clogged", "Dirty sewage is flowing onto the street",
        "Stormwater drains are full of debris", "The drainage cover is missing",
        "A sewage pipe has burst near the houses", "The gutter is clogged with mud",
        "Rainwater is accumulating due to blocked drains", "The underground sewer is leaking",
        "Drainage maintenance is urgently required", "The manhole is overflowing during rain",
        "A foul smelling sewage line needs cleaning", "The stormwater channel is not draining",
        "The neighborhood drain is backing up", "The sewer opening has a broken lid",
    ],
    "Public Safety": [
        "A dangerous exposed electrical wire is hanging low", "An unsafe open construction pit needs barricading",
        "People are reporting harassment in the public area", "A damaged electrical junction box is sparking",
        "A fallen power cable is creating immediate danger", "There is an unsecured construction site beside the school",
        "An abandoned structure is at risk of collapse", "Public safety barriers have been removed",
        "There is a risk of electric shock from loose wires", "An unsafe building facade may fall onto pedestrians",
        "A broken fence exposes pedestrians to machinery", "Emergency safety inspection is needed for loose cables",
        "Please secure the hazardous roadside electrical cabinet", "A dangerous open utility pit is accessible to children",
        "An unsafe broken railing is beside the stairs", "Construction material is falling into the public walkway",
    ],
    "Parks & Trees": [
        "A fallen tree is blocking the park entrance", "The public garden plants are not being maintained",
        "A large tree branch is hanging over the playground", "The park benches are broken",
        "The children's playground swings are damaged", "The park lawn needs mowing",
        "A diseased tree may fall in the public park", "The park walking track is covered by branches",
        "Public garden irrigation is broken", "The playground has damaged equipment",
        "Please trim the overgrown trees in the park", "The public park fence is damaged",
        "A fallen branch needs removal from the playground", "Park grass and shrubs have grown too tall",
        "The park's children's slide is broken", "A tree in the public garden needs inspection",
    ],
}
PLACES = [
    "near the college gate", "in Ward 12", "beside the bus stop", "on 3rd Cross",
    "near the municipal office", "in our neighborhood", "by the market", "outside the primary school",
    "close to the main junction", "on the residential lane", "near the community hall", "at the bus terminal",
    "in Sector 4", "near the hospital entrance",
]
PREFIX = [
    "Please take action:", "I would like to report that", "Residents noticed that",
    "This is a complaint:", "We need assistance because", "Could the city office check this?",
    "Our neighborhood reports that", "I am writing to inform you that",
    "Kindly investigate:", "Please arrange an inspection:", "This has been reported:",
    "We are facing a problem:", "The local community says", "I want to notify officials that",
]
SUFFIX = [
    "It has been an issue for three days.", "Please look into it soon.",
    "Many residents are affected.", "We would appreciate a response.",
    "It needs the attention of local staff.", "Please send the responsible team.",
    "Residents have already complained.", "Can this be checked this week?",
    "This is affecting the surrounding homes.", "A repair team may be needed.",
    "Please register this problem.", "It is causing inconvenience.",
    "Kindly provide an update.", "The issue is continuing.",
]

def generate(path: Path | None = None) -> Path:
    target = path or ROOT / "data" / "synthetic_civic_complaints.csv"
    target.parent.mkdir(parents=True, exist_ok=True)
    rng = random.Random(2026)
    rows = []
    # Entire templates 12-15 are reserved for testing for every category.
    for category, templates in CATEGORIES.items():
        assert len(templates) == 16
        for ti, text in enumerate(templates):
            split = "train" if ti < 12 else "test"
            for variant in range(14):
                place = PLACES[(variant + ti * 3) % len(PLACES)]
                prefix = PREFIX[(variant * 3 + ti) % len(PREFIX)]
                suffix = SUFFIX[(variant * 5 + ti) % len(SUFFIX)]
                detail = f"{text} {place}. {suffix}" if variant % 2 else f"{prefix} {text.lower()} {place}. {suffix}"
                rows.append({"description": detail, "category": category,
                             "template_group": f"{category}::{ti}", "split": split})
    rng.shuffle(rows)
    with target.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["description", "category", "template_group", "split"])
        writer.writeheader()
        writer.writerows(rows)
    return target

if __name__ == "__main__":
    print(generate())
