# CivicAI — Internal Assessment and 40-Mark Project Review

## Problem statement
Citizen complaints concerning public infrastructure are unstructured, difficult to sort and may not receive timely acknowledgement. This academic prototype demonstrates how a classical text classifier and a generative large language model can assist with triage, summaries and acknowledgments. It does not connect to municipal services.

## Objectives
1. Collect verified email, a text description and a complaint document.
2. Classify civic complaints into one of seven topics using TF-IDF + LinearSVC.
3. Use Gemini LLM to interpret uploaded PDF, text, and image attachments, and generate summary, priority suggestion, and acknowledgement.
4. Save a ticket and email a real receipt with original uploaded document.
5. Demonstrate trackable statuses, local administrative dashboard and honest accuracy evaluation (reported separately in the notebook).

## GenAI concepts demonstrated
- Prompt engineering with strict categories and structured JSON
- Multimodal LLM reasoning about text, PDFs and images
- LLM text generation (summaries and acknowledgements)
- Hybrid AI: supervised ML for classification, Gemini LLM for generative tasks
- Human-in-the-loop review, fallback handling, model evaluation, safety/privacy consent

## Architecture
`Citizen email -> SMTP OTP verification -> Description & file upload -> TF-IDF + LinearSVC classifier -> Gemini LLM (optional) -> SQLite ticket -> SMTP receipt with attached original file -> Admin review/updates`

## Datasets and the **accurate claim**
- Synthetic, generated train: **1176** complaints.
- Synthetic, held-out test: **392** complaints with templates disjoint from training.
- Accuracy: **100%** on held-out synthetic test; macro F1 = **1.000**.
- Additional manually written evaluation set: **42** complaints.
- Classifier accuracy: **41/42 = 97.62%**; macro F1 = **0.976**.
- One challenge misclassification: 'A broken bridge railing creates a fall hazard' was classified as Parks & Trees instead of Public Safety.
- Both sets are artificial, limited, and English only. Field performance is unknown.
- **Gemini LLM classification accuracy has not been measured**. Evaluate it with the notebook's optional API cell using the same manually labeled examples.

## Suggested demonstrations for review
1. Email-first flow, OTP delivery, verify, upload TXT/PDF, submit, receipt with original attachment.
2. Show Gemini input and its output alongside ML classification; point out ML and LLM are different.
3. Log into Admin Dashboard, show the four summary cards, category donut chart and recent cases, update a ticket status, then track the complaint. No resolution-status chart or accuracy tab is shown.
4. Run Notebook -> show category counts, held-out test, confusion matrix, 97.62% challenge accuracy, and error analysis.
5. Present limitations and explain why synthetic-test accuracy does not imply real deployment accuracy.

## Viva questions to expect
**Where is Generative AI?** Gemini analyzes uploaded content and creates summaries, priorities, and citizen-facing text.

**Which is the LLM?** Gemini, called through the `google-genai` SDK. The classical classifier is LinearSVC, not an LLM.

**How is accuracy calculated?** Number of correctly classified complaints divided by total labeled test complaints, measured with scikit-learn. The test set excludes training templates.

**How did you reach >94%?** On 42 independently worded but still handcrafted English examples, 41 predictions matched the labels (97.62%). This is a restricted benchmark, not real-world or Gemini accuracy.

**Is email really sent?** Yes, if SMTP credentials are configured, the user verifies email using an emailed code, and the SMTP server accepts the receipt. The original file is included as a MIME attachment; otherwise the app explicitly reports email was not sent.

**What improvements are needed?** Larger real-world, consented and labeled datasets; Kannada-language testing; genuine multiclass multi-issue handling; calibration, model monitoring, security controls and municipal API integration.
