"""Local scikit-learn civic complaint classifier (not itself an LLM)."""
from __future__ import annotations
from functools import lru_cache
from pathlib import Path
import joblib

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / 'models' / 'category_classifier.joblib'

@lru_cache(maxsize=1)
def load_classifier():
    if not MODEL_PATH.is_file():
        raise FileNotFoundError('ML classifier not trained. Run: python train_model.py')
    return joblib.load(MODEL_PATH)

def predict_category(text: str) -> str:
    if not text.strip():
        raise ValueError('Enter a complaint description')
    return str(load_classifier().predict([text])[0])
