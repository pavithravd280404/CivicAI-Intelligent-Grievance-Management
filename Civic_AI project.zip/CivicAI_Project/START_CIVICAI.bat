@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Python environment not found.
  echo From PowerShell inside this folder, run: python -m venv .venv
  echo Then run: .venv\Scripts\python.exe -m pip install -r requirements-demo.txt
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m streamlit run app.py
if errorlevel 1 pause
