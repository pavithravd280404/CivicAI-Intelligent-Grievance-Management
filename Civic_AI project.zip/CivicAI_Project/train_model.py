"""Train and rigorously evaluate classifier on held-out synthetic templates.

Usage: python train_model.py
"""
from __future__ import annotations
import json
from pathlib import Path
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
from data.generate_dataset import generate, ROOT, CATEGORIES


def train_and_evaluate(save: bool = True) -> tuple[Pipeline, dict, pd.DataFrame]:
    csv_path = generate()
    df = pd.read_csv(csv_path)
    train = df[df['split'] == 'train'].copy()
    test = df[df['split'] == 'test'].copy()
    assert not set(train['template_group']).intersection(test['template_group']), 'Template leakage!'
    assert not set(train['description']).intersection(test['description']), 'Duplicate leakage!'
    pipe = Pipeline([
        ('features', FeatureUnion([
            ('word', TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, min_df=2)),
            ('char', TfidfVectorizer(analyzer='char_wb', ngram_range=(3, 5), min_df=2, sublinear_tf=True)),
        ])),
        ('classifier', LinearSVC(C=1.6, class_weight='balanced', random_state=42)),
    ])
    pipe.fit(train['description'], train['category'])
    pred = pipe.predict(test['description'])
    labels = sorted(CATEGORIES)
    metrics = {
        'dataset_origin': 'synthetic, code-generated',
        'evaluation_method': 'held-out templates (no train-test template overlap)',
        'train_rows': int(len(train)),
        'test_rows': int(len(test)),
        'categories': labels,
        'category_accuracy': round(float(accuracy_score(test['category'], pred)), 6),
        'macro_f1': round(float(f1_score(test['category'], pred, average='macro')), 6),
        'weighted_f1': round(float(f1_score(test['category'], pred, average='weighted')), 6),
        'per_class': classification_report(test['category'], pred, output_dict=True, zero_division=0),
        'confusion_matrix': confusion_matrix(test['category'], pred, labels=labels).tolist(),
    }
    results = test[['description', 'category', 'template_group']].copy()
    results['predicted_category'] = pred
    results['correct'] = results['category'] == results['predicted_category']
    if save:
        (ROOT / 'models').mkdir(exist_ok=True)
        (ROOT / 'reports').mkdir(exist_ok=True)
        joblib.dump(pipe, ROOT / 'models' / 'category_classifier.joblib')
        (ROOT / 'reports' / 'ml_metrics.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')
        results.to_csv(ROOT / 'reports' / 'ml_test_predictions.csv', index=False)
    return pipe, metrics, results

if __name__ == '__main__':
    _, m, result = train_and_evaluate()
    print(f"Train: {m['train_rows']} | Test: {m['test_rows']} | Test accuracy: {m['category_accuracy']:.2%} | Macro F1: {m['macro_f1']:.4f}")
    print(f"Misclassified: {len(result) - int(result['correct'].sum())}")
    print('NOTE: Synthetic benchmark only. NOT accuracy on real-world citizen complaints.')
