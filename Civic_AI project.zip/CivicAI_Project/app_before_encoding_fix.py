from __future__ import annotations
from local_llm_service import analyze_with_local_llm
from pathlib import Path
import html
import hmac
import os
import secrets
import time

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from database import (init_db, save_complaint, get_ticket, list_complaints,
                      update_email_status, update_status, get_attachment, STATUSES, DB_PATH)
from email_service import (configured as smtp_configured, email_valid,
                           MAX_FILE_BYTES, send_verification_code, send_receipt)
from genai_service import (analyze_with_gemini, configured as gemini_configured,
                          DEPARTMENTS)
from ml_model import predict_category, MODEL_PATH
from admin_logic import filter_admin_complaints
from offline_analysis import demo_mode_enabled, analyze_offline, route_category_offline

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / '.env', override=True)
DEMO_MODE = demo_mode_enabled()
st.set_page_config(page_title='CivicAI | GenAI Civic Dashboard', page_icon='ðŸ™ï¸', layout='wide', initial_sidebar_state='expanded')
init_db()

# Keep the CSS in an editable file so the real Streamlit app matches the design.
CSS_PATH = ROOT / 'assets' / 'dashboard.css'
st.markdown(f'<style>{CSS_PATH.read_text(encoding="utf-8")}</style>', unsafe_allow_html=True)


def header(title: str, subtitle: str, description: str | None = None):
    description = description or 'A student-built civic grievance portal using machine learning and Generative AI.'
    st.markdown(
        '<section class="civic-hero"><div class="civic-hero-inner">'
        '<div class="civic-hero-kicker">âœ¦ &nbsp; GenAI university project</div>'
        f'<h1><span>{html.escape(title)}</span></h1>'
        f'<h2>{html.escape(subtitle)}</h2>'
        f'<p>{html.escape(description)}</p>'
        '</div></section>', unsafe_allow_html=True)


def clear_verified_email():
    for k in ('verified_email', 'otp_code', 'otp_time', 'otp_attempts',
              'otp_email', 'last_otp_send', 'demo_email'):
        st.session_state.pop(k, None)


def email_gate() -> bool:
    """Require an email first. In SMTP mode, it must pass an actual emailed OTP."""
    verified = st.session_state.get('verified_email')
    if verified:
        c1, c2 = st.columns([4, 1])
        c1.success(f'Email step complete: {verified}')
        if c2.button('Change email', key='reset_email'):
            clear_verified_email()
            st.rerun()
        if st.session_state.get('demo_email'):
            st.warning('Demo mode: this address is NOT verified and automatic email is DISABLED.')
        return True

    st.subheader('Step 1 Â· Enter your email address')
    st.write('You must enter an email **before** the complaint upload form becomes available.')
    email = st.text_input('Your email address', key='user_email', placeholder='yourname@example.com')
    if not email_valid(email):
        st.caption('Enter a valid email address to continue.')
        return False

    if DEMO_MODE:
        st.info('ðŸ“Œ CLASSROOM DEMO MODE: No OTP or email is sent. Your email is saved locally with the complaint only.')
        if st.button('Continue to complaint form (offline demo)', type='primary'):
            st.session_state['verified_email'] = email.strip()
            st.session_state['demo_email'] = True
            st.rerun()
        return False

    if not smtp_configured():
        st.warning('SMTP credentials are not configured. Real email verification is unavailable.')
        demo = st.checkbox('Continue in LOCAL DEMO without sending email', key='demo_optin')
        if st.button('Continue to upload', type='primary', disabled=not demo):
            st.session_state['verified_email'] = email.strip()
            st.session_state['demo_email'] = True
            st.rerun()
        return False

    now = time.monotonic()
    wait = max(0, 60 - int(now - st.session_state.get('last_otp_send', -1e9)))
    if st.button('Email me a 6-digit verification code', disabled=bool(wait), type='primary'):
        code = f'{secrets.randbelow(1_000_000):06d}'
        try:
            send_verification_code(email.strip(), code)
        except Exception as exc:
            st.error(f'Could not send verification email: {exc}')
        else:
            st.session_state.update({'otp_code': code, 'otp_time': time.monotonic(),
                'otp_email': email.strip(), 'otp_attempts': 0, 'last_otp_send': time.monotonic()})
            st.success('Verification code sent. Check your inbox and spam folder.')
    elif wait:
        st.caption(f'You may request another code in approximately {wait} seconds.')

    if st.session_state.get('otp_code'):
        with st.form('verify_email_form'):
            submitted_code = st.text_input('Enter the verification code', max_chars=6)
            verify = st.form_submit_button('Verify email')
        if verify:
            stored_email = st.session_state.get('otp_email', '')
            age = time.monotonic() - st.session_state.get('otp_time', 0)
            attempts = st.session_state.get('otp_attempts', 0)
            if email.strip() != stored_email:
                st.error('Email changed. Request a new code for this email.')
            elif age > 600:
                st.error('Code expired. Request a new one.')
                st.session_state.pop('otp_code', None)
            elif attempts >= 5:
                st.error('Too many attempts. Request a new code.')
                st.session_state.pop('otp_code', None)
            elif hmac.compare_digest(submitted_code.strip(), st.session_state['otp_code']):
                st.session_state['verified_email'] = email.strip()
                st.session_state['demo_email'] = False
                st.session_state.pop('otp_code', None)
                st.rerun()
            else:
                st.session_state['otp_attempts'] = attempts + 1
                st.error('Incorrect code.')
    return False


def render_submit():
    header('CivicAI â€” Submit a Civic Complaint',
           ('Email â†’ complaint file â†’ offline ML classification â†’ ticket tracking'
            if DEMO_MODE else
            'Email verification â†’ complaint file â†’ ML classification + Gemini analysis â†’ email receipt'))
    if DEMO_MODE:
        st.info('Offline classroom demonstration: the ML model works locally. Gemini and real emails are disabled. No government agency is contacted.')
    if not email_gate():
        return
    st.subheader('Step 2 Â· Add complaint details and upload your file')
    if not MODEL_PATH.exists():
        st.warning('ML model file missing. Run `python train_model.py` in VS Code before submitting.')
    with st.form('complaint_form', clear_on_submit=False):
        left, right = st.columns(2)
        name = left.text_input('Full name *', max_chars=100)
        location = right.text_input('Issue location *', placeholder='Ward 12, Bengaluru', max_chars=180)
        description = st.text_area('Describe the complaint *', height=115, max_chars=3000,
            placeholder='The streetlight near the college gate has been off for three nights...')
        uploaded = st.file_uploader('Upload your complaint file * (PDF, TXT, JPG or PNG; max 4 MB)',
                                    type=['pdf', 'txt', 'jpg', 'jpeg', 'png'])
        if DEMO_MODE:
            st.caption('Your uploaded file is stored locally for admin review. It is not sent to Gemini or by email in demo mode.')
        else:
            st.caption('Your file will be stored in the local SQLite database for administrator review, '
                       'attached to your email receipt, and sent to Gemini only if configured.')
        consent = st.checkbox(
    'I consent to processing this complaint and using '
    'the local Qwen2.5 Large Language Model (LLM) '
    'for AI-powered complaint analysis.'
)
        submit = st.form_submit_button('Analyze & Submit Complaint', type='primary', use_container_width=True)
    if not submit:
        return
    if not name.strip() or not location.strip() or len(description.strip()) < 15:
        st.error('Enter your name, location, and at least 15 characters describing the issue.')
        return
    if uploaded is None:
        st.error('Please upload a complaint file before submitting.')
        return
    if not consent:
        st.error('Consent is required to process your complaint.')
        return
    raw = uploaded.getvalue()
    if not raw or len(raw) > MAX_FILE_BYTES:
        st.error('The file must be nonempty and at most 4 MB.')
        return
    suffix = Path(uploaded.name).suffix.casefold()
    mime = {'.pdf':'application/pdf', '.txt':'text/plain', '.jpg':'image/jpeg',
            '.jpeg':'image/jpeg', '.png':'image/png'}.get(suffix)
    if mime is None:
        st.error('Unsupported file extension.')
        return
    if mime == 'application/pdf' and not raw.startswith(b'%PDF'):
        st.error('This does not appear to be a valid PDF.')
        return
    if mime == 'image/png' and not raw.startswith(b'\x89PNG\r\n\x1a\n'):
        st.error('This does not appear to be a valid PNG.')
        return
    if mime == 'image/jpeg' and not raw.startswith(b'\xff\xd8'):
        st.error('This does not appear to be a valid JPEG.')
        return
    ml_input = description.strip()
    if mime == 'text/plain':
        ml_input += '\n' + raw.decode('utf-8', errors='replace')[:3000]

    try:
        with st.spinner('Classifying complaint with the trained ML model...'):
            raw_ml_category = predict_category(ml_input)
            ml_category, category_rule_applied = (
                route_category_offline(ml_input, raw_ml_category) if DEMO_MODE
                else (raw_ml_category, False)
            )
    except Exception as exc:
        st.error(f'ML prediction failed: {exc}')
        return

    llm_status = "Local Qwen LLM not called"
    llm_result = None

    try:
        with st.spinner("Local Qwen LLM is analyzing your complaint..."):
            llm_result = analyze_with_local_llm(
                description, raw, mime
            )
        llm_status = "Local Qwen2.5 LLM successful"
    except Exception as exc:
        llm_status = f"Local Qwen LLM error: {str(exc)[:180]}"
        st.warning(
            f"Qwen analysis failed. Your complaint will still "
            f"be recorded. {exc}"
        )

    offline_result = analyze_offline(description, ml_category) if DEMO_MODE else None
    priority = (llm_result['priority'] if llm_result else
                offline_result['priority'] if offline_result else 'Not assessed')
    summary = (llm_result['summary'] if llm_result else
               offline_result['summary'] if offline_result else description.strip()[:350])
    citizen_reply = (llm_result['citizen_reply'] if llm_result else
                     offline_result['citizen_reply'] if offline_result else
                     'Complaint recorded in the academic demo. AI-generated acknowledgement unavailable.')
    record = {
        'name':name.strip(), 'email':st.session_state['verified_email'],
        'location':location.strip(), 'description':description.strip(),
        'attachment_name':uploaded.name, 'category_ml':ml_category,
        'category_llm':llm_result['category'] if llm_result else None,
        'priority':priority, 'department':DEPARTMENTS[ml_category],
        'summary':summary, 'citizen_reply':citizen_reply, 'llm_status':llm_status,
    }
    ticket = save_complaint(record, attachment_bytes=raw, attachment_mime=mime)
    status_message = 'Not sent (local demo mode)'
    if not DEMO_MODE and not st.session_state.get('demo_email') and smtp_configured():
        try:
            send_receipt(record['email'], ticket, ml_category, priority,
                         description.strip(), uploaded.name, raw, mime)
            status_message = 'Sent via SMTP'
        except Exception as exc:
            status_message = f'Failed: {str(exc)[:190]}'
    update_email_status(ticket, status_message)

    st.success(f'Complaint successfully saved! Ticket ID: {ticket}')
    a, b, c = st.columns(3)
    a.metric('Category', ml_category)
    b.metric('Priority suggestion', priority)
    c.metric(
        'LLM analysis',
        'Available' if llm_result is not None else 'Unavailable'
    )
    st.write('**Responsible department (suggested):**', DEPARTMENTS[ml_category])
    st.write('**Summary:**', summary)
    st.write('**Citizen acknowledgment:**', citizen_reply)
    st.write('**LLM:**', llm_status)
    if DEMO_MODE and category_rule_applied:
        st.caption(f'Routing clarification: raw ML predicted {raw_ml_category!r}; a documented offline rule routed this explicit stray-animal complaint to Public Safety.')
    if DEMO_MODE:
        st.caption('Priority is suggested by simple offline rules, not an LLM. The category is predicted by the trained local ML classifier.')
    if status_message == 'Sent via SMTP':
        st.success(f'A complaint receipt and your uploaded file were emailed to {record["email"]}.')
    else:
        st.warning(f'Email receipt was NOT sent: {status_message}')
    st.info('Academic demonstration only: your complaint was NOT sent to a real civic department.')


def render_tracking():
    header('Track Your Complaint', 'Your ticket ID and registered email address are both required.')
    with st.form('track_form'):
        ticket = st.text_input('Ticket ID', placeholder='CIV-0123456789')
        email = st.text_input('Your registered email')
        lookup = st.form_submit_button('Look up ticket', type='primary')
    if lookup:
        item = get_ticket(ticket, email)
        if item is None:
            st.error('Ticket not found for this email address.')
        else:
            a, b, c = st.columns(3)
            a.metric('Status', item['status'])
            b.metric('Category', item['category_ml'])
            c.metric('Priority', item['priority'])
            st.write('**Location:**', item['location'])
            st.write('**Summary:**', item['summary'])
            st.write('**Email delivery status:**', item['email_status'])
            st.caption('The status is maintained within this prototype only.')


def _clean(value: object) -> str:
    """Escape database fields before inserting them in dashboard HTML."""
    return html.escape(str(value if value is not None else ''), quote=True)


def _badge(value: str, kind: str) -> str:
    label = str(value or 'Not assessed')
    if kind == 'priority':
        cls = {'high': 'high', 'medium': 'medium', 'low': 'low'}.get(label.lower(), 'other')
        return f'<span class="civic-priority {cls}">{_clean(label)}</span>'
    cls = ({'done': 'resolved', 'in progress': 'inprogress',
            'pending': 'pending', 'resolved': 'resolved', 'submitted': 'pending',
            'under review': 'pending'}).get(label.lower(), 'other')
    return f'<span class="civic-status {cls}">{_clean(label)}</span>'


def _recent_table(rows: list[dict], *, private: bool) -> str:
    """Public dashboard only exposes synthetic seed records, never real submissions."""
    if private:
        visible = rows[:8]
    else:
        visible = [r for r in rows if str(r.get('llm_status', '')).startswith('Seeded demo')][:8]
    if not visible:
        if rows:
            return ('<p class="civic-muted">Recent citizen complaint details are restricted to '
                    'the authenticated administrator. Sign in to see them.</p>')
        return ('<p class="civic-muted">No complaints yet. Submit a complaint, or run '
                '<code>python seed_demo.py</code> to load fictional showcase records.</p>')

    html_rows = []
    for row in visible:
        date = str(row.get('created_at', ''))[:16].replace('T', ' ')
        summary = str(row.get('summary') or '')
        if len(summary) > 90:
            summary = summary[:87] + '...'
        email = row.get('email', '') if private or str(row.get('llm_status', '')).startswith('Seeded demo') else 'Restricted'
        html_rows.append(
            '<tr>'
            f'<td><span class="civic-ticket">{_clean(row.get("ticket"))}</span></td>'
            f'<td>{_clean(email)}</td>'
            f'<td>{_clean(row.get("category_ml"))}</td>'
            f'<td>{_clean(summary)}</td>'
            f'<td>{_badge(row.get("priority"), "priority")}</td>'
            f'<td>{_badge(row.get("status"), "status")}</td>'
            f'<td>{_clean(date)}</td>'
            '</tr>'
        )
    return ('<div class="civic-table-wrap"><table class="civic-table">'
            '<thead><tr><th>Ticket ID</th><th>Email</th><th>Category</th>'
            '<th>AI Summary / Complaint</th><th>Priority</th><th>Status</th><th>Filed On (UTC)</th>'
            '</tr></thead><tbody>' + ''.join(html_rows) + '</tbody></table></div>')


def render_dashboard(*, private: bool = False, interactive: bool = False) -> None:
    """Wide visual dashboard matching the provided CivicAI design reference."""
    header('CivicAI', 'Smart Public Grievance Management System (GenAI + LLM)',
           'Submit, classify and track complaints locally. Optional Gemini LLM integration is included.')
    rows = list_complaints()
    total = len(rows)
    resolved = sum(r['status'] == 'Done' for r in rows)
    progress = sum(r['status'] == 'In Progress' for r in rows)
    pending = sum(r['status'] == 'Pending' for r in rows)
    demo_only = bool(rows) and all(str(r.get('llm_status', '')).startswith('Seeded demo') for r in rows)
    if demo_only:
        st.info('SHOWCASE DATA: These are fictional example complaints added with seed_demo.py, not live municipal records.')
    elif not rows:
        st.info('No complaint records yet. To preview the design using fictional examples, run `python seed_demo.py` once, then refresh.')

    values = [
        ('â–¤', 'Total Complaints', total, 'total'),
        ('âœ“', 'Done', resolved, 'resolved'),
        ('âŸ³', 'In Progress', progress, 'progress'),
        ('â—·', 'Pending', pending, 'pending'),
    ]
    if interactive:
        # Native Streamlit controls are clickable; HTML-only KPI cards are not.
        for (symbol, label, n, key), col in zip(values, st.columns(4)):
            target = {'total': 'All', 'resolved': 'Done', 'progress': 'In Progress',
                      'pending': 'Pending'}[key]
            with col:
                with st.container(key=f'admin_card_{key}'):
                    if st.button(f'{symbol}   {label}  Â·  {n:,}', key=f'admin_card_button_{key}',
                                 use_container_width=True, type='secondary',
                                 help=f'View {target.lower()} complaints'):
                        st.session_state['admin_status_filter'] = target
                        st.session_state['admin_selected_ticket'] = None
                        st.session_state.pop('admin_search', None)
                        st.rerun()
        st.caption('Select a status box above; the matching complaint cards appear immediately below. Click Open details to view citizen information.')
        return
    else:
        cards = []
        for icon_symbol, label, n, key in values:
            cards.append(f'<div class="civic-kpi kpi-{key}"><div class="civic-kpi-icon">{icon_symbol}</div>'
                         f'<div><div class="civic-kpi-caption">{_clean(label)}</div>'
                         f'<div class="civic-kpi-number">{n:,}</div></div></div>')
        st.markdown('<div class="civic-stats">' + ''.join(cards) + '</div>', unsafe_allow_html=True)

    palette = ['#944bff', '#257bff', '#21c6ed', '#17cda4', '#ff65b6', '#ffca48', '#ff8d65', '#729bff']
    counts = pd.Series([r['category_ml'] for r in rows]).value_counts() if rows else pd.Series(dtype='int64')
    angle = 0.0
    segments, legend = [], []
    for i, (category, n) in enumerate(counts.items()):
        color = palette[i % len(palette)]
        next_angle = angle + (n / total * 100) if total else angle
        segments.append(f'{color} {angle:.2f}% {next_angle:.2f}%')
        legend.append('<div class="civic-legend-row"><div class="civic-legend-name">'
                      f'<span class="civic-legend-dot" style="background:{color}"></span>'
                      f'{_clean(category)}</div><div class="civic-legend-count">'
                      f'{n:,} ({n / total:.0%})</div></div>')
        angle = next_angle
    gradient = 'conic-gradient(' + ','.join(segments) + ')' if segments else 'conic-gradient(#253355 0% 100%)'
    chart = (
        '<section class="civic-panel"><h3 class="civic-panel-title">â—ˆ &nbsp; Complaints by Category</h3>'
        '<div class="civic-chart-layout">'
        f'<div class="civic-donut" style="--donut-fill:{gradient}"><div class="civic-donut-hole">'
        f'<span class="civic-donut-number">{total:,}</span><span class="civic-donut-sub">Total<br>Complaints</span>'
        '</div></div><div class="civic-legend">'
        + (''.join(legend) if legend else '<p class="civic-muted">Category information appears once complaints are submitted.</p>')
        + '</div></div></section>'
    )
    st.markdown(chart, unsafe_allow_html=True)

    if not interactive:
        st.markdown('<section class="civic-panel"><h3 class="civic-panel-title">â–¤ &nbsp; Recent Complaints</h3>'
                    + _recent_table(rows, private=private) + '</section>', unsafe_allow_html=True)
    if not interactive:
        footer = ('Offline ML demonstration â€¢ Gemini integration available in code' if DEMO_MODE
                  else 'Powered by Generative AI / Google Gemini')
        st.markdown('<div class="civic-footer"><div style="font-size:2rem">âœ§</div><div>'
                f'<strong>{html.escape(footer)}</strong>'
                '<small>Local ML Classification &nbsp; â€¢ &nbsp; Complaint Tracking &nbsp; â€¢ &nbsp; '
                'Admin Review &nbsp; â€¢ &nbsp; Optional Gemini &amp; Email Integration</small></div></div>',
                unsafe_allow_html=True)
    if DEMO_MODE:
        st.caption('ðŸŸ£ LOCAL DEMO MODE â€” offline ML only. Gemini LLM and real emails are not used. '
                   'The Gemini integration and independent ML accuracy notebook are provided in the project files.')
    else:
        if not gemini_configured():
            st.caption('Gemini key not configured. Only offline ML is available.')
        if not smtp_configured():
            st.caption('Email SMTP is not configured. OTP and receipt emails are unavailable.')


def render_admin():
    """Authenticated admin case browser with dependable native Streamlit buttons."""
    password = os.getenv('ADMIN_PASSWORD', '').strip()
    if not password:
        header('Admin Dashboard', 'Administrator sign-in required')
        st.warning('Set ADMIN_PASSWORD in `.env` to enable the administrator dashboard.')
        return
    if not st.session_state.get('admin_authenticated'):
        header('Admin Dashboard', 'Secure access to complaint details and case management.')
        with st.form('admin_login'):
            pwd = st.text_input('Administrator password', type='password')
            login = st.form_submit_button('Sign in to dashboard', type='primary')
        if login:
            if hmac.compare_digest(pwd, password):
                st.session_state['admin_authenticated'] = True
                st.session_state['admin_status_filter'] = 'All'
                st.session_state.pop('admin_selected_ticket', None)
                st.rerun()
            else:
                st.error('Incorrect administrator password.')
        return

    top_left, top_right = st.columns([5, 1])
    top_left.caption('Private administrator area â€¢ citizen contact details are visible only after sign-in.')
    if top_right.button('Sign out', key='admin_logout'):
        st.session_state['admin_authenticated'] = False
        st.session_state.pop('admin_selected_ticket', None)
        st.rerun()
        return

    if st.session_state.get('admin_saved_status_message'):
        st.success(st.session_state.pop('admin_saved_status_message'))

    # This renders real clickable KPI buttons, then returns before the chart.
    render_dashboard(private=True, interactive=True)
    rows = list_complaints()
    current_filter = st.session_state.get('admin_status_filter', 'All')
    if current_filter not in ('All', *STATUSES):
        current_filter = 'All'
        st.session_state['admin_status_filter'] = 'All'

    st.markdown(f'### ðŸ“¬ {current_filter} complaints')
    query = st.text_input('Search complaints by ticket, name, email, category or location',
                          placeholder='Search name, email or ticket ID...', key='admin_search')
    selected_rows = filter_admin_complaints(rows, current_filter, query)
    st.caption(f'{len(selected_rows)} matching complaint(s) â€¢ click **Open details** to view the full record.')

    if not selected_rows:
        st.info('No complaints match this filter. Click Total Complaints and clear the search to see all records. '
                'If the total is 0, submit a complaint first or run seed_demo.py for fictional examples.')
        st.caption(f'Local database: {DB_PATH} â€¢ total saved records: {len(rows)}')
        return

    visible_tickets = {r['ticket'] for r in selected_rows}
    chosen_ticket = st.session_state.get('admin_selected_ticket')
    if chosen_ticket not in visible_tickets:
        chosen_ticket = None

    # Keep the opened record directly beneath the filters so it is visible after reruns,
    # instead of hiding the details below a long chart/table.
    if chosen_ticket:
        record = next(r for r in selected_rows if r['ticket'] == chosen_ticket)
        st.markdown('### ðŸ”Ž Selected complaint details')
        with st.container(border=True):
            a, b = st.columns(2)
            a.write(f'**Ticket ID:** {record["ticket"]}')
            a.write(f'**Citizen name:** {record["name"]}')
            a.write(f'**Citizen email:** {record["email"]}')
            a.write(f'**Location:** {record["location"]}')
            a.write(f'**Submitted at (UTC):** {record["created_at"]}')
            b.write(f'**Current status:** {record["status"]}')
            b.write(f'**Complaint category:** {record["category_ml"]}')
            b.write(f'**Gemini category:** {record["category_llm"] or "Not available"}')
            b.write(f'**AI priority:** {record["priority"]}')
            b.write(f'**Suggested department:** {record["department"]}')
            st.markdown('**Full original complaint**')
            st.text_area('Citizen description', value=record['description'], height=110,
                         disabled=True, key=f'admin_description_{chosen_ticket}')
            st.write('**AI-generated / saved summary:**', record['summary'])
            st.write('**Citizen acknowledgment:**', record['citizen_reply'])
            st.write('**LLM processing status:**', record['llm_status'])
            st.write('**Receipt email status:**', record['email_status'])
            attachment = get_attachment(chosen_ticket)
            if attachment:
                st.write('**Uploaded evidence:**', attachment['filename'])
                st.download_button('â¬‡ï¸ Download uploaded complaint file',
                                   data=attachment['contents'],
                                   file_name=Path(attachment['filename']).name,
                                   mime=attachment['mime'],
                                   key=f'admin_download_{chosen_ticket}')
            elif record.get('attachment_name'):
                st.warning(f'Uploaded filename: {record["attachment_name"]}. '
                           'Older submissions may not have saved the original file.')
            else:
                st.caption('No uploaded file retained for this complaint.')

        with st.form(f'admin_status_{chosen_ticket}'):
            st.markdown('#### Update complaint status')
            new_status = st.radio('Select status', STATUSES,
                                  index=STATUSES.index(record['status']) if record['status'] in STATUSES else 0,
                                  horizontal=True)
            submitted = st.form_submit_button('ðŸ’¾ Save status', type='primary')
        if submitted:
            update_status(chosen_ticket, new_status)
            st.session_state['admin_saved_status_message'] = (
                f'Saved: {chosen_ticket} â†’ {new_status}. Citizen tracking now shows this status.')
            # Keep the details visible even after a complaint moves out of its old status filter.
            st.session_state['admin_status_filter'] = 'All'
            st.session_state['admin_selected_ticket'] = chosen_ticket
            st.rerun()
        if st.button('âœ• Close details', key='close_admin_case'):
            st.session_state['admin_selected_ticket'] = None
            st.rerun()

    st.markdown('#### Complaints â€” select one to open')
    # Native buttons are supported across Streamlit versions and do not depend on
    # dataframe row-selection APIs or non-interactive HTML.
    shown = selected_rows[:50]
    if len(selected_rows) > 50:
        st.caption('Showing first 50 matches. Use the search field to find a specific citizen or ticket.')
    for item in shown:
        with st.container(border=True):
            left, middle, right = st.columns([3, 2, 1.1], vertical_alignment='center')
            left.markdown(f'**{item["ticket"]}** â€” {item["name"]}')
            left.caption(f'âœ‰ï¸ {item["email"]}  â€¢  ðŸ“ {item["location"]}')
            middle.markdown(f'**{item["category_ml"]}**')
            middle.caption(f'{item["status"]} â€¢ {item["priority"]} priority')
            if right.button('Open details', key=f'open_case_{item["ticket"]}',
                            use_container_width=True,
                            type='primary' if item['ticket'] == chosen_ticket else 'secondary'):
                st.session_state['admin_selected_ticket'] = item['ticket']
                st.rerun()

    with st.expander('Export full administrative records'):
        st.caption('Private data: export only to a trusted location. Do not expose citizen emails publicly.')
        df = pd.DataFrame(rows)
        st.download_button('Download CSV report', df.to_csv(index=False),
                           'civicai_admin_export.csv', 'text/csv')


def render_about():
    header('About CivicAI', 'Hybrid ML + optional GenAI university mini-project â€¢ not an official grievance service')
    if DEMO_MODE:
        st.warning('Offline demo mode is ON. ML classification, database, file upload, admin status updates and tracking work locally. Gemini LLM analysis, OTP verification and actual email receipts are OFF.')
    if DEMO_MODE:
        st.caption('The local classifier is TF-IDF + LinearSVC. A transparent rule routes explicitly mentioned stray-dog problems to Public Safety if necessary. This rule is separate from classifier-only accuracy measurements.')
    st.markdown('''### Processing pipeline

1. Citizen enters an email first. With SMTP configured, they verify a one-time code.
2. Citizen uploads a complaint file and describes the issue.
3. A **TF-IDF + LinearSVC** classifier predicts one of seven categories.
4. **Google Gemini LLM** reads the complaint and, if enabled, the PDF/image/text file to
   suggest priority, generate a concise summary and citizen acknowledgment.
5. The complaint is saved in SQLite, and a **real SMTP email** is sent containing the
   ticket details and the original file as an attachment (when email is configured).
6. Admin opens a complaint from the interactive table and sets **Pending**, **In Progress**, or **Done**.

**Model evaluation:** The training and evaluation notebook is supplied separately for your
academic report; accuracy metrics are intentionally not displayed in the website.

**Privacy:** Emails, descriptions and uploaded files are stored in local SQLite for
administrator review. Use fictional sample data in demonstrations; restrict access to this database.

Uploaded content can be sent to Google when Gemini is enabled.

**Limits:** For classroom/local demonstrations only. Not a government portal. The app has no
municipal backend connection, real staff assignment, production rate limiting or file scanning.
''')


pages = ['ðŸ“Š Dashboard', 'ðŸ“ Submit Complaint', 'ðŸ”Ž Track Complaint', 'ðŸ›¡ï¸ Admin Dashboard', 'â„¹ï¸ About Project']
with st.sidebar:
    st.markdown("""<div class="civic-brand"><div class="civic-brand-icon">ðŸ™ï¸</div>
    <div><div class="civic-brand-name">CivicAI</div><div class="civic-brand-kicker">SMART CIVIC HELPDESK</div></div></div>
    <p class="civic-sidebar-note">University project prototype</p>
    <div class="civic-sidebar-divider"></div>""", unsafe_allow_html=True)
    page = st.radio('Navigation', pages, index=0, label_visibility='collapsed')
    engine = ('Offline ML â€¢ Gemini integration available' if DEMO_MODE
              else 'Gemini configured (API not verified)' if gemini_configured()
              else 'Gemini available after API setup')
    email_mode = ('Email notifications off (demo)' if DEMO_MODE
                  else 'SMTP configured (delivery not verified)' if smtp_configured()
                  else 'SMTP setup required for emails')
    st.markdown(f"""<div class="civic-side-ai"><h3>âœ¦ &nbsp; GenAI + LLM</h3>
        <div class="subtitle">Powered by</div><div class="gemini">{html.escape(engine)}</div>
        <span class="star">âœ§</span>
        <div class="feature"><span>âœ“</span> Intelligent complaint analysis</div>
        <div class="feature"><span>âœ“</span> Automatic summarization</div>
        <div class="feature"><span>âœ“</span> Smart ML categorization</div>
        <div class="feature"><span>âœ“</span> {html.escape(email_mode)}</div>
        <div class="feature"><span>âœ“</span> PDF / image evidence</div></div>""", unsafe_allow_html=True)
    st.caption('Local academic prototype â€¢ no government integration')
    if DEMO_MODE:
        st.info('DEMO MODE â€¢ No Gemini API or Gmail setup required. Emails are recorded but not verified or sent.')

if page == 'ðŸ“Š Dashboard':
    render_dashboard(private=bool(st.session_state.get('admin_authenticated')))
    if st.session_state.get('admin_authenticated'):
        st.info('The overview cards above show totals. To open individual complaints and see citizen emails, select **ðŸ›¡ï¸ Admin Dashboard** in the sidebar.')
    else:
        st.caption('Admin: sign in through ðŸ›¡ï¸ Admin Dashboard to view individual complaint details.')
elif page == 'ðŸ“ Submit Complaint':
    render_submit()
elif page == 'ðŸ”Ž Track Complaint':
    render_tracking()
elif page == 'ðŸ›¡ï¸ Admin Dashboard':
    render_admin()
else:
    render_about()
