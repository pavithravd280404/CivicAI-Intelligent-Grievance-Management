from admin_logic import filter_admin_complaints
from database import init_db, list_complaints, save_complaint, update_status


def test_filters_display_real_emails_and_all_three_statuses(tmp_path):
    db = tmp_path / 'cases.sqlite3'
    init_db(db)
    for idx, desired in enumerate(('Pending', 'In Progress', 'Done')):
        ticket = save_complaint({
            'name': f'Citizen {idx}', 'email': f'citizen{idx}@example.com',
            'location': 'Ward 1', 'description': 'streetlight needs repair',
            'attachment_name': 'complaint.txt', 'category_ml': 'Street Lighting',
            'category_llm': 'Street Lighting', 'priority': 'Medium',
            'department': 'Electrical', 'summary': 'Light out',
            'citizen_reply': 'Acknowledged', 'llm_status': 'offline',
        }, db, attachment_bytes=b'photo evidence', attachment_mime='text/plain')
        update_status(ticket, desired, db)
    all_rows = list_complaints(db)
    assert len(filter_admin_complaints(all_rows, 'All')) == 3
    for idx, status in enumerate(('Pending','In Progress','Done')):
        matches = filter_admin_complaints(all_rows, status)
        assert len(matches) == 1
        assert matches[0]['email'] == f'citizen{idx}@example.com'
    assert len(filter_admin_complaints(all_rows, 'All', 'citizen1@example.com')) == 1
    assert len(filter_admin_complaints(all_rows, 'Done', 'citizen1@example.com')) == 0
    assert len(filter_admin_complaints(all_rows, 'All', 'streetlight')) == 3
    assert filter_admin_complaints(all_rows, 'All', 'NOT-FOUND') == []
