from __future__ import annotations
from email_service import _send


def test_send_receipt_attachment_mock(monkeypatch):
    sent = []
    class FakeSMTP:
        def __init__(self, *args, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, exc_type, exc, tb): pass
        def login(self, user, password):
            assert user == 'sender@example.com'
            assert password == 'app-pass'
        def send_message(self, message): sent.append(message)
    monkeypatch.setenv('SMTP_USER', 'sender@example.com')
    monkeypatch.setenv('SMTP_PASSWORD', 'app-pass')
    monkeypatch.setenv('SMTP_FROM', 'sender@example.com')
    monkeypatch.setattr('email_service.smtplib.SMTP_SSL', FakeSMTP)
    _send('student@example.com','Receipt','Thank you',
          'complaint.txt', b'Please fix the lamp','text/plain')
    assert len(sent) == 1
    assert sent[0]['To'] == 'student@example.com'
    files = list(sent[0].iter_attachments())
    assert len(files) == 1
    assert files[0].get_filename() == 'complaint.txt'
    assert files[0].get_content() == 'Please fix the lamp'
