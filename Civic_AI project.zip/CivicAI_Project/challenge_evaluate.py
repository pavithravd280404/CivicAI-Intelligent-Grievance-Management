"""Extra small, handcrafted (still not real-world) challenge evaluation."""
from __future__ import annotations
import json
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, f1_score
from ml_model import load_classifier
from data.generate_dataset import ROOT


def run():
    df = pd.read_csv(ROOT/'data'/'challenge_complaints.csv')
    model = load_classifier()
    pred = model.predict(df['description'])
    acc = float(accuracy_score(df['category'], pred))
    macro = float(f1_score(df['category'], pred, average='macro'))
    result = df.copy()
    result['predicted_category'] = pred
    result['correct'] = result['category'] == result['predicted_category']
    (ROOT/'reports').mkdir(exist_ok=True)
    result.to_csv(ROOT/'reports'/'challenge_predictions.csv', index=False)
    metrics = {'dataset_origin': 'small handcrafted classroom stress-test, not field data',
               'test_rows': len(df), 'accuracy': acc, 'macro_f1': macro,
               'per_class': classification_report(df['category'], pred, output_dict=True, zero_division=0)}
    (ROOT/'reports'/'challenge_metrics.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')
    return result, metrics

if __name__ == '__main__':
    result, metrics = run()
    print(f"Challenge accuracy: {metrics['accuracy']:.2%} | F1: {metrics['macro_f1']:.3f}")
    print('Misclassified:')
    print(result.loc[~result['correct'], ['description','category','predicted_category']].to_string(index=False))
